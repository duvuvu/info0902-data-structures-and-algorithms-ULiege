
#include <stddef.h>

#include "BP.h"
#include "Disk.h"
#include "File.h"
#include "LinkedList.h"

/*
    Implementation of the Next-Fit strategy
*/

size_t binpacking(size_t diskSize, List *files, List *disks)
{
    return 0;
}
