// Placez ici votre implémentation d'arbre binaire de recherche pour BP_bestfit.c
