#!/bin/bash

gcc avl_bf.c avl_data.c avl_test.c && time ./a.out
